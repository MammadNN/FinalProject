
$(document).ready(function () {
    $('#CustomerAdnBlogCarousel .owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
});
// carousel Custom buttons
$(".testimonial .carousel_customButtons #prev").click(function () {
    $(".testimonial .owl-prev").click();
})
$(".testimonial .carousel_customButtons #next").click(function () {
    $(".testimonial .owl-next").click();
})

$(".ourlatestnews .carousel_customButtons #prev").click(function () {
    $(".ourlatestnews .owl-prev").click();
})
$(".ourlatestnews .carousel_customButtons #next").click(function () {
    $(".ourlatestnews .owl-next").click();
})

// Home page Corousel
$('#Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})
// //////////////////////////

// About page corousel
$('#About_Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})
////////////////////////////

////Agents page Carousel 
$('#Agents_Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})
//////////////////////////////////////////

//////Properties page corousel 
$('#Properties_Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})


$(document).ready(function () {
    $('#CustomerAdnBlogCarousel .owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })

    $("#list_tabs li.fil-li a.fil-a").click(function (event) {
        event.preventDefault();
        $("#list_tabs li.fil-li a.fil-a.active").removeClass("active");
        $(this).addClass("active");
        var filter = $(event.target).attr("data-filter");

        $("#list_products .product-cart").each(function () {
            var item = $(this);
            if (item.attr("data-category").indexOf(filter) != -1) item.show();
            else item.hide();
        });
    });

    // /* This is basic - uses default settings */

    // $("a#single_image").fancybox();

    // /* Using custom settings */

    // $("a#inline").fancybox({
    //     'hideOnContentClick': true
    // });

    // /* Apply fancybox to multiple items */

    // $("a.group").fancybox({
    //     'transitionIn': 'elastic',
    //     'transitionOut': 'elastic',
    //     'speedIn': 600,
    //     'speedOut': 200,
    //     'overlayShow': false
    // });
});
// carousel Custom buttons
$(".testimonial .carousel_customButtons #prev").click(function () {
    $(".testimonial .owl-prev").click();
})
$(".testimonial .carousel_customButtons #next").click(function () {
    $(".testimonial .owl-next").click();
})

$(".ourlatestnews .carousel_customButtons #prev").click(function () {
    $(".ourlatestnews .owl-prev").click();
})
$(".ourlatestnews .carousel_customButtons #next").click(function () {
    $(".ourlatestnews .owl-next").click();
})

// Home page Corousel
$('#Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})
// //////////////////////////

// About page corousel
$('#About_Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})
////////////////////////////

////Agents page Carousel 
$('#Agents_Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})
//////////////////////////////////////////

//////Properties page corousel 
$('#Properties_Company .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})

$('#PropertiesItem .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
})
